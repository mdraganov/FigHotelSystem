﻿namespace HotelSystemApp.Interfaces
{
    public interface ICleanable
    {
        bool CleanRoom { get; set; }

        void ToogleCleanRoom();
    }

    // DELETE ??
}
