﻿namespace HotelSystemApp.Enumerations
{
    public enum Rooms
    { 
        Apartment,
        OneBedroom,
        TwoBedrooms,
        Studio
    }
}
