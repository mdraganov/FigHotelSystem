﻿namespace HotelSystemApp.Enumerations
{
    public enum SpaProcedures
    {
        Sauna = 20,
        RomanBath = 25,
        Hydrotherapy = 30
    }
}
