﻿namespace HotelSystemApp.Enumerations
{
    public enum EmployeesEnum
    {
        BellBoy = 1,
        Maid = 2,
        Manager = 3,
        Receptionist = 4
    }
}
