﻿namespace HotelSystemApp.Enumerations
{
    public enum MenuEnum
    {
        MainMenu,
        ClientsMenu,
        StaffMenu,
        Reservations
    }
}
